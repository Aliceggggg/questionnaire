import React, { useState } from 'react';
import { PlusCircle, Save, PlayCircle, Trash2, ChevronRight, Users, BarChart3, Layout, FileText } from 'lucide-react';

interface Question {
  id: string;
  text: string;
  type: 'text' | 'choice' | 'rating' | 'scale';
  options?: string[];
  required?: boolean;
  description?: string;
}

interface SurveySettings {
  welcomeMessage: string;
  thankYouMessage: string;
}

function App() {
  const [showBuilder, setShowBuilder] = useState(false);
  const [showPreview, setShowPreview] = useState(false);
  const [title, setTitle] = useState('');
  const [questions, setQuestions] = useState<Question[]>([]);
  const [settings, setSettings] = useState<SurveySettings>({
    welcomeMessage: '',
    thankYouMessage: '',
  });

  const addQuestion = () => {
    const newQuestion: Question = {
      id: Date.now().toString(),
      text: '',
      type: 'text',
      options: [],
      required: false,
      description: '',
    };
    setQuestions([...questions, newQuestion]);
  };

  const updateQuestion = (id: string, updates: Partial<Question>) => {
    setQuestions(questions.map(q => 
      q.id === id ? { ...q, ...updates } : q
    ));
  };

  const deleteQuestion = (id: string) => {
    setQuestions(questions.filter(q => q.id !== id));
  };

  const addOption = (questionId: string) => {
    const question = questions.find(q => q.id === questionId);
    if (question && question.options) {
      updateQuestion(questionId, {
        options: [...question.options, '']
      });
    }
  };

  const handleSaveSurvey = () => {
    const survey = {
      title,
      questions,
      settings,
      createdAt: new Date().toISOString(),
    };
    localStorage.setItem('savedSurvey', JSON.stringify(survey));
    alert('Опрос успешно сохранен!');
  };

  const PreviewSurvey = () => (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-50 py-8">
      <div className="container mx-auto px-4">
        <div className="max-w-2xl mx-auto">
          <div className="bg-white rounded-xl shadow-lg p-6">
            <div className="mb-8">
              <h1 className="text-2xl font-bold text-gray-800 mb-4">{title}</h1>
              {settings.welcomeMessage && (
                <p className="text-gray-600">{settings.welcomeMessage}</p>
              )}
            </div>

            <form className="space-y-6">
              {questions.map((question, index) => (
                <div key={question.id} className="border border-gray-200 rounded-lg p-4">
                  <p className="font-medium mb-2">
                    {index + 1}. {question.text}
                    {question.required && <span className="text-red-500 ml-1">*</span>}
                  </p>
                  {question.description && (
                    <p className="text-sm text-gray-600 mb-3">{question.description}</p>
                  )}

                  {question.type === 'text' && (
                    <textarea
                      className="w-full p-2 border border-gray-300 rounded"
                      rows={3}
                      required={question.required}
                    />
                  )}

                  {question.type === 'choice' && (
                    <div className="space-y-2">
                      {question.options?.map((option, i) => (
                        <label key={i} className="flex items-center">
                          <input
                            type="radio"
                            name={`question-${question.id}`}
                            required={question.required}
                            className="mr-2"
                          />
                          {option}
                        </label>
                      ))}
                    </div>
                  )}

                  {question.type === 'rating' && (
                    <div className="flex gap-2">
                      {[1, 2, 3, 4, 5].map((value) => (
                        <button
                          key={value}
                          type="button"
                          className="w-10 h-10 rounded-full border-2 border-purple-500 flex items-center justify-center hover:bg-purple-500 hover:text-white transition-colors"
                        >
                          {value}
                        </button>
                      ))}
                    </div>
                  )}

                  {question.type === 'scale' && (
                    <div className="flex gap-2">
                      {Array.from({ length: 10 }, (_, i) => i + 1).map((value) => (
                        <button
                          key={value}
                          type="button"
                          className="w-8 h-8 rounded border border-gray-300 flex items-center justify-center hover:bg-purple-500 hover:text-white hover:border-purple-500 transition-colors"
                        >
                          {value}
                        </button>
                      ))}
                    </div>
                  )}
                </div>
              ))}

              <div className="flex justify-between mt-8">
                <button
                  type="button"
                  onClick={() => setShowPreview(false)}
                  className="px-4 py-2 text-gray-600 hover:text-gray-800"
                >
                  Вернуться к редактированию
                </button>
                <button
                  type="submit"
                  className="px-6 py-2 bg-purple-600 text-white rounded-lg hover:bg-purple-700 transition-colors"
                >
                  Отправить ответы
                </button>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  );

  const LandingPage = () => (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 via-white to-blue-50">
      <nav className="bg-white shadow-sm">
        <div className="container mx-auto px-4 py-4 flex justify-between items-center">
          <div className="text-2xl font-bold text-purple-600">ОпросПро</div>
          <button
            onClick={() => setShowBuilder(true)}
            className="px-6 py-2 bg-purple-600 text-white rounded-full hover:bg-purple-700 transition-colors"
          >
            Создать опрос
          </button>
        </div>
      </nav>

      <div className="container mx-auto px-4 py-16">
        <div className="text-center mb-16">
          <h1 className="text-5xl font-bold text-gray-900 mb-6">
            Создавайте профессиональные опросы за минуты
          </h1>
          <p className="text-xl text-gray-600 mb-8">
            Самый простой способ создавать опросы, собирать ответы и анализировать результаты
          </p>
          <button
            onClick={() => setShowBuilder(true)}
            className="px-8 py-3 bg-purple-600 text-white rounded-full text-lg hover:bg-purple-700 transition-colors flex items-center gap-2 mx-auto"
          >
            Начать сейчас <ChevronRight size={20} />
          </button>
        </div>

        <div className="grid md:grid-cols-3 gap-8 mb-16">
          <div className="bg-white p-6 rounded-xl shadow-sm">
            <div className="text-purple-600 mb-4">
              <Layout size={32} />
            </div>
            <h3 className="text-xl font-semibold mb-2">Просто использовать</h3>
            <p className="text-gray-600">Создавайте профессиональные опросы с помощью нашего интуитивного конструктора</p>
          </div>
          <div className="bg-white p-6 rounded-xl shadow-sm">
            <div className="text-purple-600 mb-4">
              <Users size={32} />
            </div>
            <h3 className="text-xl font-semibold mb-2">Сбор ответов</h3>
            <p className="text-gray-600">Делитесь своим опросом и собирайте ответы от вашей аудитории</p>
          </div>
          <div className="bg-white p-6 rounded-xl shadow-sm">
            <div className="text-purple-600 mb-4">
              <BarChart3 size={32} />
            </div>
            <h3 className="text-xl font-semibold mb-2">Анализ результатов</h3>
            <p className="text-gray-600">Получайте аналитику в реальном времени и детальные отчеты</p>
          </div>
        </div>

        <div className="text-center">
          <h2 className="text-3xl font-bold mb-4">Готовы начать?</h2>
          <button
            onClick={() => setShowBuilder(true)}
            className="px-8 py-3 bg-purple-600 text-white rounded-full text-lg hover:bg-purple-700 transition-colors"
          >
            Создать ваш первый опрос
          </button>
        </div>
      </div>
    </div>
  );

  const SurveyBuilder = () => (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-50 py-8">
      <div className="container mx-auto px-4">
        <div className="max-w-4xl mx-auto">
          <div className="flex justify-between items-center mb-8">
            <h1 className="text-3xl font-bold text-gray-800">
              Создать новый опрос
            </h1>
            <button
              onClick={() => setShowBuilder(false)}
              className="text-gray-600 hover:text-gray-800"
            >
              Вернуться на главную
            </button>
          </div>

          <div className="bg-white rounded-xl shadow-lg p-6 mb-6">
            <input
              type="text"
              placeholder="Название опроса"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              className="w-full text-2xl font-semibold border-b-2 border-gray-200 focus:border-purple-500 outline-none pb-2 mb-6"
            />

            {questions.map((question) => (
              <div key={question.id} className="mb-6 p-4 border border-gray-200 rounded-lg hover:border-purple-200 transition-colors">
                <div className="flex gap-4 mb-4">
                  <input
                    type="text"
                    placeholder="Текст вопроса"
                    value={question.text}
                    onChange={(e) => updateQuestion(question.id, { text: e.target.value })}
                    className="flex-1 p-2 border border-gray-300 rounded focus:border-purple-500 focus:ring-1 focus:ring-purple-500"
                  />
                  <select
                    value={question.type}
                    onChange={(e) => updateQuestion(question.id, { 
                      type: e.target.value as Question['type'],
                      options: ['text', 'scale'].includes(e.target.value) ? undefined : ['']
                    })}
                    className="p-2 border border-gray-300 rounded focus:border-purple-500 focus:ring-1 focus:ring-purple-500"
                  >
                    <option value="text">Текстовый ответ</option>
                    <option value="choice">Множественный выбор</option>
                    <option value="rating">Рейтинг</option>
                    <option value="scale">Шкала (1-10)</option>
                  </select>
                  <button
                    type="button"
                    onClick={() => deleteQuestion(question.id)}
                    className="p-2 text-red-500 hover:text-red-700 transition-colors"
                  >
                    <Trash2 size={20} />
                  </button>
                </div>

                <input
                  type="text"
                  placeholder="Описание вопроса (необязательно)"
                  value={question.description || ''}
                  onChange={(e) => updateQuestion(question.id, { description: e.target.value })}
                  className="w-full p-2 mb-4 border border-gray-300 rounded text-sm text-gray-600"
                />

                {question.type === 'choice' && (
                  <div className="ml-4">
                    {question.options?.map((option, index) => (
                      <input
                        key={index}
                        type="text"
                        placeholder={`Вариант ${index + 1}`}
                        value={option}
                        onChange={(e) => {
                          const newOptions = [...(question.options || [])];
                          newOptions[index] = e.target.value;
                          updateQuestion(question.id, { options: newOptions });
                        }}
                        className="block w-full p-2 mb-2 border border-gray-300 rounded focus:border-purple-500 focus:ring-1 focus:ring-purple-500"
                      />
                    ))}
                    <button
                      type="button"
                      onClick={() => addOption(question.id)}
                      className="text-purple-600 hover:text-purple-700 flex items-center gap-2"
                    >
                      <PlusCircle size={16} />
                      Добавить вариант
                    </button>
                  </div>
                )}

                <div className="mt-4 flex items-center">
                  <input
                    type="checkbox"
                    id={`required-${question.id}`}
                    checked={question.required}
                    onChange={(e) => updateQuestion(question.id, { required: e.target.checked })}
                    className="mr-2"
                  />
                  <label htmlFor={`required-${question.id}`} className="text-sm text-gray-600">
                    Обязательный вопрос
                  </label>
                </div>
              </div>
            ))}

            <div className="flex justify-between mt-6">
              <button
                type="button"
                onClick={addQuestion}
                className="flex items-center gap-2 px-4 py-2 bg-purple-600 text-white rounded-lg hover:bg-purple-700 transition-colors"
              >
                <PlusCircle size={20} />
                Добавить вопрос
              </button>

              <div className="flex gap-2">
                <button
                  type="button"
                  onClick={handleSaveSurvey}
                  className="flex items-center gap-2 px-4 py-2 bg-green-500 text-white rounded-lg hover:bg-green-600 transition-colors"
                >
                  <Save size={20} />
                  Сохранить опрос
                </button>
                <button
                  type="button"
                  onClick={() => setShowPreview(true)}
                  className="flex items-center gap-2 px-4 py-2 bg-blue-500 text-white rounded-lg hover:bg-blue-600 transition-colors"
                >
                  <PlayCircle size={20} />
                  Предпросмотр
                </button>
              </div>
            </div>
          </div>

          <div className="bg-white rounded-xl shadow-lg p-6">
            <h2 className="text-xl font-semibold mb-4 flex items-center gap-2">
              <FileText size={24} className="text-purple-600" />
              Настройки опроса
            </h2>
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Приветственное сообщение
                </label>
                <textarea
                  className="w-full p-2 border border-gray-300 rounded focus:border-purple-500 focus:ring-1 focus:ring-purple-500"
                  rows={3}
                  value={settings.welcomeMessage}
                  onChange={(e) => setSettings({ ...settings, welcomeMessage: e.target.value })}
                  placeholder="Добавьте приветственное сообщение для участников опроса..."
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Сообщение благодарности
                </label>
                <textarea
                  className="w-full p-2 border border-gray-300 rounded focus:border-purple-500 focus:ring-1 focus:ring-purple-500"
                  rows={3}
                  value={settings.thankYouMessage}
                  onChange={(e) => setSettings({ ...settings, thankYouMessage: e.target.value })}
                  placeholder="Добавьте сообщение благодарности после отправки ответов..."
                />
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );

  if (showPreview) {
    return <PreviewSurvey />;
  }

  return showBuilder ? <SurveyBuilder /> : <LandingPage />;
}

export default App;